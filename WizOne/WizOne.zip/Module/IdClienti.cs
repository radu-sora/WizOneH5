﻿namespace WizOne.Module
{
    public class IdClienti
    {

		//34 - Groupama
        //65 - Banca Comerciala Carpatica
        //13 - Asirom

        public enum Clienti : int
        {
            Asirom = 13,
		    Honeywell = 14,
            Brico = 15,
            Omniasig = 16,
            Generali = 17,
			Harting = 18,
            Pelifilip = 20,
            Claim = 21,
            Dnata = 22,
            FM = 23,
            Cristim = 24,
            Franke = 25,
            Chimpex = 26,
            Groupama = 34,
            Zitec = 45,
            BancaCarpatica = 65,
            Trico = 66
        }


        //Plastipak = 17,

    }
}
